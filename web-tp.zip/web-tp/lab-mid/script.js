const viewMoreBtn = document.getElementById('viewMoreBtn');
const hiddenTestimonials = document.querySelectorAll('.testimonial.hidden');

viewMoreBtn.addEventListener('click', () => {
    hiddenTestimonials.forEach(testimonial => {
        testimonial.style.display = 'block';
        testimonial.classList.remove('hidden');
    });
    viewMoreBtn.style.display = 'none';
});
