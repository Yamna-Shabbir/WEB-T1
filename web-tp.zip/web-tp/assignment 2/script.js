$(function(){
    loadrecipies();
    $("#recipies").on("click",".btn-danger",handledelete);
    $("#recipies").on("click",".btn-warning",handleupdate);
    $("#add-btn").click(addrecipie);
    $("#updatesave").click(function(){
        var id=$("#updateid").val();
        var title=$("#updatetitle").val();
        var body=$("#updatebody").val();
       $.ajax({
        url:"https://usmanlive.com/wp-json/api/stories/"+ id,
        method:"PUT",
        data: { title, content: body },
        
        success:function(){
            alert("Story updated successfully!")
            $("#updatemodal").modal("hide");
            loadrecipies();
        }
       })
    })
});
function handleupdate(){
    
    var btn=$(this);
    var parent= btn.closest(".recipie");
    var parentid=parent.attr("data-id");
    console.log(parentid);
    $.get("https://usmanlive.com/wp-json/api/stories/"+ parentid,function(response){
        $("#updateid").val(response.id);
        $("#updatetitle").val(response.title);
        $("#updatebody").val(response.content);
        $("#updatemodal").modal("show");
    })
}
function addrecipie(){
    var title=$("#title").val();
    var body=$("#body").val();
    $.ajax({
        url:"https://usmanlive.com/wp-json/api/stories",
        method:"Post",
        data:{title, content: body},
        success:function(response){
            console.log("response");
            alert("Story added successfully!");
            loadrecipies();
        }
    });
}
function handledelete(){
    var btn=$(this);
    var parent= btn.closest(".recipie");
    var parentid=parent.attr("data-id");
    console.log(parentid);
    $.ajax({
        url: "https://usmanlive.com/wp-json/api/stories/" + parentid,
        method: "DELETE",
        success:function(){
            console.log("Deleted successfully!");
            alert("Story deleted successfully!");
            loadrecipies();
        }
    });
}
function loadrecipies(){
    $.ajax({
        url:"https://usmanlive.com/wp-json/api/stories",
        method:"Get",
        success:function(response){
            console.log(response);
            var recipies=$("#recipies");
            recipies.empty();
            for(var i=0;i<response.length;i++){
                var res=response[i];
                recipies.append(`<div class="recipie" data-id=${res.id}><h3>${res.title}</h3><p>${res.content} 
                    <button class="btn btn-danger btn-sm float-end">Delete</button>
                    <button class="btn btn-warning btn-sm float-end">Edit</button>
                    </p></div>`)
          }
        }
    });
}