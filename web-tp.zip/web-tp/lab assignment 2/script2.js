$(document).ready(function(){

  // Enable submit button only if checkbox is checked
  $("#agreeCheck").change(function(){
    $("#placeOrderBtn").prop("disabled", !this.checked);
  });

  // Dynamic card fields
  $("input[name='payment[]']").change(function() {
    if ($("#card").is(":checked")) {
      $(".card-field").attr("required", true);
    } else {
      $(".card-field").removeAttr("required");
    }
  });

  // Form validation
  $("#form").validate({
    rules: {
      fullName: { required:true, minlength:3 },
      email: { required:true, email:true },
      phone: { required:true, digits:true, minlength:10 },
      address: { required:true },
      city: { required:true },
      postal: { required:true, number:true, minlength:4, maxlength:6 },
      'payment[]': { required:true },
      country: { required:true }
    },
    messages: {
      fullName: "Please enter at least 3 characters.",
      email: "Enter a valid email.",
      phone: "Enter 10+ digits.",
      address: "Enter your address.",
      city: "Enter your city.",
      postal: "Enter 4-6 digit postal code.",
      'payment[]': "Select a payment method.",
      country: "Select your country."
    },
    submitHandler: function(form) {
      // Redirect when form is valid
      window.location.href = "success.html"; // adjust path as needed
      return false; // prevent normal form submission
    }
  });

});
