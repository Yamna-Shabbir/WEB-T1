$(function () {
  $("#agreeCheck").change(function () {
    // enable the button only when checkbox is checked
    $("#placeOrderBtn").prop("disabled", !this.checked);
  });
});
$(document).ready(function(){
    $("#form").validate({
        rules:{
            fullName : {
                required:true,
                minlength:3,
            },
            email:{
                email:true,
                required:true,
    },
        address:{
            required:true,
        },
        city:{
            required:true,
        },
        phone:{
            required:true,
            digits:true,
            minlength:10,
        },
        postal:{
            required:true,
            number:true,
            minlength:4,
            maxlength:6,
        },
        'payment[]':{
            required:true,
        },
        country: {
            required: true
        }

        },
    messages: {
      fullName: {
        required: "Please enter your full name.",
        minlength:"Minimum Character for the name should be three",
      },
      email:{
        email:"Not a valid email format",
        required:"Please enter the email."
      },
      address:{
            required:"Please enter your address.",
        },
        city:{
            required:"Please enter your city name.",
        },
        phone:{
            required:"Please enter your city name.",
            digits:"Digits only.",
            minlength:"Minimum 10 digits."
        },
        postal:{
            required:"Please enter the postal code.",
            number:"Numbers only",
            minlength:"Minimum 4 digits.",
            maxlength:"Maximum 6 digits",
        },
        'payment[]':{
            required:"Please select any payment option!",
        },
        country: {
            required: "Please select your country."
}


    },
    
    //called khud hi when it fails to validate
    // error basically bs aik error msgs hai jo mila hai thru plugins 
    //element is the input field (like <input id="fullName">) that caused the validation error.
    errorPlacement: function(error, element) {
      // element ka parent i.e name is inside  a parent wid form-floating div
      if (element.parent(".form-floating").length) {
        error.insertAfter(element.parent());  // place error after the .form-floating wrapper
      } else {
        error.insertAfter(element); // default behavior
      }
    },
    highlight: function(element) {
  $(element).addClass("is-invalid").removeClass("is-valid");
},
unhighlight: function(element) {
  $(element).addClass("is-valid").removeClass("is-invalid");
},
invalidHandler: function(event, validator) {
  if (validator.numberOfInvalids()) {
    const firstInvalid = $(validator.errorList[0].element);
    $('html, body').animate({
      scrollTop: firstInvalid.offset().top - 100
    }, 600);
    firstInvalid.focus();
  }
}

    });
    // Dynamically handle card field validation based on payment selection
  $("input[name='payment[]']").change(function() {
    if ($("#card").is(":checked")) {
      // If 'Card' is selected, make card fields required
      $(".card-field").attr("required", true);
    } else {
      // Otherwise, remove the required attribute
      $(".card-field").removeAttr("required");
    }
  });
 


});